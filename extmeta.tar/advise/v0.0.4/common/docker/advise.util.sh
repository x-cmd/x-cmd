# shellcheck shell=dash     disable=2207,3030,2034
# For docker complete advise

# # Section: List images
# ___x_cmd_advise_exec___docker_ls_images_id(){
#     command docker images --all --quiet
# }

___x_cmd_advise_exec___docker_ls_images_name(){
    command docker image ls --all --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | awk '$0 !~ /<none>/'
}
# # EndSection

# # Section: List container
# ___x_cmd_advise_exec___docker_ls_container_id(){
#     command docker container ls --all -q
# }

___x_cmd_advise_exec___docker_ls_container_name(){
    command docker container ls --all --format '{{.Names}}' 2>/dev/null
}
# # EndSection

# # Section: List network
# ___x_cmd_advise_exec___docker_ls_network_id(){
#     command docker network ls -q
# }

# ___x_cmd_advise_exec___docker_ls_network_name(){
#     command docker network ls  --format '{{.Name}}' --no-trunc
# }
# # EndSection

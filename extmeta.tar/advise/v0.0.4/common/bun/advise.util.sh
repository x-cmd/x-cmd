# shellcheck shell=dash disable=SC1091,SC2034,SC3030,SC2207

[ ! -f "$___X_CMD_ADVISE_MAN_XCMD_FOLDER/common/npm/advise.util.sh"  ] || . "$___X_CMD_ADVISE_MAN_XCMD_FOLDER/common/npm/advise.util.sh"

___x_cmd_advise_exec___bun_ls_script_without_subcmd(){
    [ -f "./package.json" ] || return
    local IFS="$___X_CMD_UNSEENCHAR_NEWLINE"
    candidate_exec_arr=($(
        if [ -n "$ZSH_VERSION" ]; then
            x ja '
            function genO (result, args,     _i, _l, _arr){
                _l = split(args, _arr, " ")
                for (_i=1; _i<=_l; ++_i)    result[_arr[_i]] = "true"
            }
            END{
                genO( bun_O, "help run test x repl create c init i add a remove rm r uninstall update link unlink pm build upgrade" )
                l = O[ kp(1, "scripts") L ]
                for (i=1; i<=l; ++i) {
                    key      = juq(O[ kp(1, "scripts", i) ])
                    if (bun_O[key])     continue
                    key_desc = juq(O[ kp(1, "scripts-info", key) ])

                    gsub(":", "\\:", key)
                    if (key_desc)       print key ":" key_desc
                    else                print key
                }
            }' < "./package.json"
        else
            x ja '
            function genO (result, args,     _i, _l, _arr){
                _l = split(args, _arr, " ")
                for (_i=1; _i<=_l; ++_i)    result[_arr[_i]] = "true"
            }
            END{
                genO( bun_O, "help run test x repl create c init i add a remove rm r uninstall update link unlink pm build upgrade" )
                l = O[ kp(1, "scripts") L ]
                for (i=1; i<=l; ++i) {
                    if (bun_O[ juq(O[ kp(1, "scripts", i) ]) ])     continue
                    print juq(O[ kp(1, "scripts", i) ])
                }
            }' < "./package.json"
        fi
    ))
}

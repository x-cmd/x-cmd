# shellcheck shell=dash disable=SC2034,SC3030,SC2207

___x_cmd_advise_exec___czg_which_config_() {
    local _tmp=""; while read -r _tmp; do
        if [ -f "$_tmp" ]; then
            x_="$_tmp"
            return
        fi
    done <<A
./.czrc
./.commitlintrc
./.commitlintrc.json
./.commitlintrc.js
./.commitlintrc.cjs
./.commitlintrc.mjs
./commitlint.config.js
./commitlint.config.cjs
./commitlint.config.mjs
./cz.config.js
./cz.config.cjs
./cz.config.mjs
$HOME/.czrc
$HOME/.commitlintrc
$HOME/.commitlintrc.json
$HOME/.commitlintrc.js
$HOME/.commitlintrc.cjs
$HOME/.commitlintrc.mjs
$HOME/commitlint.config.js
$HOME/commitlint.config.cjs
$HOME/commitlint.config.mjs
$HOME/cz.config.js
$HOME/cz.config.cjs
$HOME/cz.config.mjs
A
}

___x_cmd_advise_exec___output_json_config_(){
    [ -n "$x_" ] || return
    case "$x_" in
        *.js|*.cjs|*.mjs)
            ___x_cmd_hascmd node || return
            ___x_cmd_cmds node -e ";(async () => { const a = await import('${x_}'); console.log(JSON.stringify(a.default || a)) })()"
        ;;
        *)
            ___x_cmd_cmds cat "$x_"
        ;;
    esac
}

___x_cmd_advise_exec___output_alias_by_config_(){
    [ -n "$x_" ] || return
    if [ -n "$ZSH_VERSION" ]; then
        x ja   -v CONFIG="$x_" 'END{
            if (CONFIG ~ "(.czrc|cz.config.c?js|cz.config.m?js)$") {
                l = O[ kp(1, "alias") L ]
                for (i=1; i<=l; ++i) {
                    key      = juq(O[ kp(1, "alias", i) ])
                    key_desc = juq(O[ kp(1, "alias", key) ])

                    gsub(":", "\\:", key)
                    if (key_desc)   print key ":" key_desc
                    else            print key
                }
            } else {
                l = O[ kp(1, "prompt", "alias") L ]
                for (i=1; i<=l; ++i) {
                    key      = juq(O[ kp(1, "prompt", "alias", i) ])
                    key_desc = juq(O[ kp(1, "prompt", "alias", key) ])

                    gsub(":", "\\:", key)
                    if (key_desc)   print key ":" key_desc
                    else            print key
                }
            }
        }'
    else
        x ja   -v CONFIG="$x_" 'END{
            if (CONFIG ~ "(.czrc|cz.config.c?js)$") {
                l = O[ kp(1, "alias") L ]
                for (i=1; i<=l; ++i) print juq(O[ kp(1, "alias", i) ])
            } else {
                l = O[ kp(1, "prompt", "alias") L ]
                for (i=1; i<=l; ++i) print juq(O[ kp(1, "prompt", "alias", i) ])
            }
        }'
    fi
}

___x_cmd_advise_exec___czg_ls_alias(){
    local IFS="$___X_CMD_UNSEENCHAR_NEWLINE"
    local x_=""; ___x_cmd_advise_exec___czg_which_config_
    [ -n "$x_" ] || return
    candidate_exec_arr=($(
        ___x_cmd_advise_exec___output_json_config_ | ___x_cmd_advise_exec___output_alias_by_config_
    ))
}

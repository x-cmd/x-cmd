# shellcheck shell=bash

___x_cmd_advise_exec___pip_ls_package(){
    xrc pip
    ___x_cmd_hascmd ___x_cmd_pip___nv_list || return 0
    ___x_cmd_pip___nv_list
}

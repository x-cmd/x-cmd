# shellcheck shell=dash disable=SC1091,SC2034,SC3030,SC2207

[ ! -f "$___X_CMD_ADVISE_MAN_XCMD_FOLDER/common/npm/advise.util.sh"  ] || . "$___X_CMD_ADVISE_MAN_XCMD_FOLDER/common/npm/advise.util.sh"

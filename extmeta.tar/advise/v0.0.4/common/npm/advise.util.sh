# shellcheck shell=dash disable=SC2034,SC3030,SC2207

___x_cmd_advise_exec___npm_ls_pacakge_json_script(){
    [ -f "./package.json" ] || return 0
    local IFS="$___X_CMD_UNSEENCHAR_NEWLINE"
    candidate_exec_arr=($(
        if [ -n "$ZSH_VERSION" ]; then
            x ja 'END{
                l = O[ kp(1, "scripts") L ]
                for (i=1; i<=l; ++i) {
                    key      = juq(O[ kp(1, "scripts", i) ])
                    key_desc = juq(O[ kp(1, "scripts-info", key) ])

                    gsub(":", "\\:", key)
                    if (key_desc)   print key ":" key_desc
                    else            print key
                }
            }' < "./package.json"
        else
            x ja 'END{
                l = O[ kp(1, "scripts") L ]
                for (i=1; i<=l; ++i) print juq(O[ kp(1, "scripts", i) ])
            }' < "./package.json"
        fi
    ))
}

___x_cmd_advise_exec___npm_ls_package(){
    if [ -f "./package.json" ]; then
        x ja '
            function print_keys ( target,   l, i ){
                l = O[ kp(1, target) L ]
                for (i=1; i<=l; ++i)        print juq(O[ kp(1, target, i) ])
            }
            END{
                print juq(O[ kp(1, "name") ])

                print_keys( "dependencies" )
                print_keys( "devDependencies" )
                print_keys( "optionalDependencies" )
                print_keys( "peerDependencies" )
            }
        ' < "./package.json"
    fi
    if [ "$1" != "--local" ]; then
        xrc npm
        ___x_cmd_hascmd ___x_cmd_npm___nv_list || return 0
        ___x_cmd_npm___nv_list
    fi
}

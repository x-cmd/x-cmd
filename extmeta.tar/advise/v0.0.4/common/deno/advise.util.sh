# shellcheck shell=dash disable=SC1091,SC2034,SC3030,SC2207

[ ! -f "$___X_CMD_ADVISE_MAN_XCMD_FOLDER/common/npm/advise.util.sh"  ] || . "$___X_CMD_ADVISE_MAN_XCMD_FOLDER/common/npm/advise.util.sh"

___x_cmd_advise_exec___deno_ls_json_keys(){
    x ja -v target="$1" 'END{
        l = O[ kp(1, target) L ]
        for (i=1; i<=l; ++i) print juq(O[ kp(1, target, i) ])
    }'
}

___x_cmd_advise_exec___deno_ls_task(){
    [ ! -f "./deno.json" ]    || ___x_cmd_advise_exec___deno_ls_json_keys "tasks"   < "./deno.json"
    [ ! -f "./package.json" ] || ___x_cmd_advise_exec___deno_ls_json_keys "scripts" < "./package.json"
}

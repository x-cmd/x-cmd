# shellcheck shell=dash     disable=2207,3030,2034
# For git complete advise

# Section: List File
# TODO: wait advise support complete path form
___x_cmd_advise_exec___git_ls_file_(){
    command git ls-files --exclude-standard "$@" --
}
___x_cmd_advise_exec___git_ls_cached_file(){ ___x_cmd_advise_exec___git_ls_file_ "--cached" ; }

___x_cmd_advise_exec___git_ls_deleted_file(){ ___x_cmd_advise_exec___git_ls_file_ "--deleted" ; }

___x_cmd_advise_exec___git_ls_modified_file(){ ___x_cmd_advise_exec___git_ls_file_ "--modified" ; }

___x_cmd_advise_exec___git_ls_other_file(){ ___x_cmd_advise_exec___git_ls_file_ "--others" ; }

___x_cmd_advise_exec___git_ls_unmerged_file(){ ___x_cmd_advise_exec___git_ls_file_ "--unmerged" ; }

___x_cmd_advise_exec___git_ls_killed_file(){ ___x_cmd_advise_exec___git_ls_file_ "--killed" ; }

___x_cmd_advise_exec___git_ls_ignored_cached_file(){ ___x_cmd_advise_exec___git_ls_file_ "--ignored" "--cached" ; }

___x_cmd_advise_exec___git_ls_ignored_other_file(){ ___x_cmd_advise_exec___git_ls_file_ "--ignored" "--others" ; }
# EndSection

# Section: List Branch
___x_cmd_advise_exec___git_ls_local_branch(){
    command git for-each-ref --format="%(refname:strip=2)" "refs/heads/*"   "refs/heads/*/**"
}

___x_cmd_advise_exec___git_ls_remote_branch(){
    command git for-each-ref --format="%(refname:strip=2)" "refs/heads/*"   "refs/heads/*/**"
}

___x_cmd_advise_exec___git_ls_branch(){
    ___x_cmd_advise_exec___git_ls_local_branch
    ___x_cmd_advise_exec___git_ls_remote_branch
}
# EndSection

# Section: List Tag
___x_cmd_advise_exec___git_ls_tag(){
    command git for-each-ref --format="%(refname:strip=2)" "refs/tags/*" "refs/tags/*/**"
}
# EndSection

# Section: List Checkout
___x_cmd_advise_exec___git_ls_usable_checkout(){
    command git for-each-ref --format="%(refname:strip=2)" "refs/heads/*"   "refs/heads/*/**"
    command git for-each-ref --format="%(refname:strip=3)" "refs/remotes/*" "refs/remotes/*/**"
    command git for-each-ref --format="%(refname:strip=2)" "refs/remotes/*" "refs/remotes/*/**"
    command git for-each-ref --format="%(refname:strip=2)" "refs/tags/*"    "refs/tags/*/**"
}
# EndSection

# Section: List Remote
___x_cmd_advise_exec___git_ls_remote(){
    command git remote
}
# EndSection

# Section: List Commits
# TODO: wait for advise can support to add description by using custom Fn
# git --no-pager rev-list -20 --format='%h%n%d%n%s\ \(%cr\)%n%p' HEAD
# git --no-pager rev-list -1000 --all --reflog --format='%h:\[%h\]\ %s\ \(%cr\)' HEAD
___x_cmd_advise_exec___git_ls_commit(){
    command git for-each-ref --format="%(refname:strip=2)" "refs/heads/*"   "refs/heads/*/**"
    printf "%s\n" "HEAD" "HEAD~" "FETCH_HEAD" "ORIG_HEAD" "MERGE_HEAD" "CHERRY_PICK_HEAD" "REVERT_HEAD" "BISECT_HEAD"
    command git for-each-ref --format="%(refname:strip=2)" "refs/remotes/*" "refs/remotes/*/**"
    command git for-each-ref --format="%(refname:strip=2)" "refs/tags/*"    "refs/tags/*/**"
}
# EndSection

# Section: List Stash
# TODO: wait for custom Fn can add description: `git stash list -z --pretty='format:%gd%x00%s%x00\(%cr\)'`
___x_cmd_advise_exec___git_ls_stash(){
    command git stash list -z --pretty='format:%gd%n'
}
# EndSection

# Section: List GPG Secret Sign Key
___x_cmd_advise_exec___git_ls_gpg_secret_sign_key(){
    command gpg --list-secret-keys 2>/dev/null | command grep -E "^uid" | command sed -E "s/.*<(.*)>.*/\1/"
}
# EndSection

# Section: List Submodules
# shellcheck disable=SC2016
___x_cmd_advise_exec___git_ls_submodule(){
    command git submodule --quiet foreach --recursive 'echo $name'
}

# EndSection

# Section: List Worktree
___x_cmd_advise_exec___git_ls_worktree(){
    command git worktree list --porcelain | command grep -E "^worktree" | command sed -E "s/^worktree\ //"
}
# EndSection

# Section: List archive
___x_cmd_advise_exec___git_ls_archive(){
    command git archive --list
}
# EndSection

# Section: List Config
___x_cmd_advise_exec___git_ls_config(){
    command git config --list
}

___x_cmd_advise_exec___git_ls_config_keys(){
    command git config --list | command cut -d "=" -f 1
}

___x_cmd_advise_exec___git_ls_config_keys_with_equal(){
    command git config --list | command sed 's/=.*$/=/'
}
# EndSection
